-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 29 Janvier 2008 à 22:12
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `db_hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `catID` int(2) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  `prix` float DEFAULT NULL,
  PRIMARY KEY (`catID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `categorie`
--


-- --------------------------------------------------------

--
-- Structure de la table `chambres`
--

CREATE TABLE IF NOT EXISTS `chambres` (
  `chID` int(3) NOT NULL AUTO_INCREMENT,
  `catID` int(2) NOT NULL,
  `etID` int(3) NOT NULL,
  `numero_ch` varchar(5) NOT NULL,
  PRIMARY KEY (`chID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `chambres`
--


-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `clID` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `cni` varchar(15) NOT NULL,
  `age` int(3) DEFAULT NULL,
  PRIMARY KEY (`clID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `clients`
--


-- --------------------------------------------------------

--
-- Structure de la table `etages`
--

CREATE TABLE IF NOT EXISTS `etages` (
  `etID` int(3) NOT NULL AUTO_INCREMENT,
  `numero_etage` int(3) NOT NULL,
  PRIMARY KEY (`etID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `etages`
--


-- --------------------------------------------------------

--
-- Structure de la table `gestion_client`
--

CREATE TABLE IF NOT EXISTS `gestion_client` (
  `gestID` int(11) NOT NULL AUTO_INCREMENT,
  `clID` int(3) NOT NULL,
  `chID` int(3) NOT NULL,
  `date_entree` date NOT NULL,
  `date_sortie` date DEFAULT NULL,
  PRIMARY KEY (`gestID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `gestion_client`
--


-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE IF NOT EXISTS `paiement` (
  `paiementID` int(11) NOT NULL AUTO_INCREMENT,
  `date_paiement` date NOT NULL,
  `montant` float NOT NULL,
  `gestID` int(11) NOT NULL,
  PRIMARY KEY (`paiementID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `paiement`
--

